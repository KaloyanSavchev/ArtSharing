﻿using ArtSharing.Data.Models.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace ArtSharing.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<User>>();
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            // 🚀 Прилага миграции, ако има нужда (не използвай EnsureCreatedAsync!)
            await context.Database.MigrateAsync();

            // 1️⃣ Добавяне на роли (User, Admin)
            if (!await roleManager.RoleExistsAsync("Admin"))
                await roleManager.CreateAsync(new IdentityRole("Admin"));

            if (!await roleManager.RoleExistsAsync("User"))
                await roleManager.CreateAsync(new IdentityRole("User"));

            // 2️⃣ Създаване на администраторски потребител
            var adminEmail = "admin@artsharing.com";
            if (await userManager.FindByEmailAsync(adminEmail) == null)
            {
                var adminUser = new User
                {
                    UserName = "admin",
                    Email = adminEmail,
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(adminUser, "Admin123!");

                if (result.Succeeded)
                    await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            // 3️⃣ Добавяне на базови категории
            if (!context.Categories.Any())
            {
                var categories = new List<Category>
                {
                    new Category { Name = "Photography" },
                    new Category { Name = "Digital Art" },
                    new Category { Name = "Traditional Art" },
                    new Category { Name = "Nature" }
                };

                context.Categories.AddRange(categories);
                await context.SaveChangesAsync();
            }

            // 4️⃣ Добавяне на тестови постове
            if (!context.Posts.Any())
            {
                var user = await userManager.FindByEmailAsync(adminEmail);
                var category = await context.Categories.FirstOrDefaultAsync();

                if (user != null && category != null)
                {
                    var posts = new List<Post>
                    {
                        new Post
                        {
                            Title = "The Rabbit and the Bear",
                            Description = "OMG look at this cute bunny I drew, it has a carrot <3!",
                            ImageUrl = "https://source.unsplash.com/400x300/?art,drawing",
                            CreatedAt = DateTime.UtcNow,
                            UserId = user.Id,
                            CategoryId = category.Id
                        }
                    };

                    context.Posts.AddRange(posts);
                    await context.SaveChangesAsync();
                }
            }
        }
    }
}
