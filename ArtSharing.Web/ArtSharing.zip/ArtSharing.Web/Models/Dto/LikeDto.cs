﻿namespace ArtSharing.Web.Models.Dto
{
    public class LikeDto
    {
        public int PostId { get; set; }
    }
}
