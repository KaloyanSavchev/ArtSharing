﻿namespace ArtSharing.Web.Models.Dto
{
    public class UserBasicDto
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
    }

}
